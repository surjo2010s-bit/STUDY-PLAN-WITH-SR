import type { TimetableData } from '../types';

export const parseMarkdownTable = (markdown: string): TimetableData | null => {
  const tableRegex = /### সাপ্তাহিক আদর্শ রুটিন\s*\|.*\|[\s\S]*/;
  const tableMatch = markdown.match(tableRegex);

  if (!tableMatch) {
    return null;
  }

  const lines = tableMatch[0].split('\n').filter(line => line.trim().startsWith('|'));

  if (lines.length < 2) {
    // Not a valid table if it doesn't have a header and at least one separator line
    return null;
  }

  const headers = lines[0]
    .split('|')
    .slice(1, -1) // Remove first and last empty strings from split
    .map(header => header.trim());
  
  // The line after headers is the separator, e.g., |:---|:---|
  // We skip it and take the rest as rows
  const rows = lines.slice(2).map(line => {
    return line
      .split('|')
      .slice(1, -1)
      .map(cell => cell.trim());
  });

  if (headers.length === 0 || rows.length === 0) {
    return null;
  }

  return { headers, rows };
};
