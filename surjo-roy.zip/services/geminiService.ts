import { GoogleGenAI } from "@google/genai";
import type { FormData } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const parseGeminiError = (error: any): string => {
  if (error && typeof error.message === 'string') {
    // Attempt to extract the user-facing message from the raw error string
    // e.g., "[GoogleGenerativeAI Error]: [400 Bad Request] API key not valid. Please pass a valid API key."
    const match = error.message.match(/\[\d{3} \w+ \w+\]\s*(.*)/);
    if (match && match[1]) {
      return match[1]; // Return the specific error like "API key not valid..."
    }
    return error.message; // Fallback to the full message
  }
  return "An unknown error occurred while communicating with the AI model.";
};

function buildPrompt(formData: FormData): string {
  const chapterInfo = formData.chapters
    ? `- Chapters to cover: The user has provided a specific list of chapters. Use this list directly. The list is: \n${formData.chapters}`
    : `- Chapters to cover: You will need to identify the standard list of chapters for each subject based on the Bangladesh National Curriculum (NCTB).`;

  const dailyWeakSubjectInstruction =
    formData.includeWeakSubjectsDaily && formData.weakSubjects
      ? `It is CRUCIAL to include the subjects listed as 'weaker subjects' (${formData.weakSubjects}) in the study plan for EVERY study day (Saturday to Thursday). After ensuring their daily inclusion, distribute the remaining subjects in a balanced way.`
      : `Prioritize weaker subjects, but ensure a balanced distribution of all subjects throughout the week.`;

  return `
You are an intelligent study planner and academic assistant for students in Bangladesh. You have deep knowledge of the Bangladesh National Curriculum (NCTB) for SSC and HSC levels.

Your entire response MUST be in the Bengali (Bangla) language.

Your task is to create a weekly study timetable based on the user's information. The plan should be logical, balanced, and easy to follow as a recurring weekly schedule.

Please use the following student information to generate the plan:
- Academic Level: ${formData.level}
- Subjects: ${formData.subjects}
- Exam Date: ${formData.examDate}
- Total available study hours per day: ${formData.studyHours}
- Weaker subjects or topics to prioritize: ${formData.weakSubjects}
- Other commitments (class/coaching): ${formData.commitments}
${chapterInfo}

Instructions for the plan:
1.  First, create a section titled "### অধ্যায় পরিচিতি" (Identified Chapters). In this section, present the chapters for each subject in a two-column Markdown table. The columns must be 'বিষয়' (Subject) and 'অধ্যায় তালিকা' (Chapter List). ${formData.chapters ? 'Use the list provided by the user.' : 'Identify the chapters based on the NCTB curriculum.'}
2.  Then, create a section titled "### সাপ্তাহিক আদর্শ রুটিন" (Ideal Weekly Routine).
3.  Generate a detailed weekly study timetable using a Markdown table. This table should represent a typical study week (Saturday to Thursday, as is common in Bangladesh).
4.  The table columns must be 'সময়' (Time), 'শনিবার' (Saturday), 'রবিবার' (Sunday), 'সোমবার' (Monday), 'মঙ্গলবার' (Tuesday), 'বুধবার' (Wednesday), 'বৃহস্পতিবার' (Thursday).
5.  Based on the user's daily study hours, create logical time slots for study sessions (e.g., 1-hour blocks).
6.  Crucially, block out the times for the student's commitments (e.g., 'School' or 'Coaching').
7.  Fill the available study slots with subjects. ${dailyWeakSubjectInstruction}
8.  Include short, 10-15 minute breaks between study sessions.
9.  The final output should be a single, comprehensive weekly timetable that the student can follow every week until their syllabus is complete.
10. Present the entire plan in a clear, column-oriented format using Markdown. The timetable is the most important part. Ensure the output is well-organized and entirely in Bengali.
  `;
}

function buildRevisionPrompt(formData: FormData, studyPlan: string): string {
  return `
You are an intelligent study planner and academic assistant for students in Bangladesh. You are following up on a study plan you just created.

Your entire response MUST be in the Bengali (Bangla) language.

You have already generated the following weekly study plan for the student:
--- STUDY PLAN START ---
${studyPlan}
--- STUDY PLAN END ---

The student's details are:
- Academic Level: ${formData.level}
- Weaker subjects: ${formData.weakSubjects}
- Daily study hours: ${formData.studyHours}

Your new task is to create a concise WEEKEND REVISION PLAN (বিশেষ রিভিশন রুটিন) for Friday, which is the weekly holiday in Bangladesh. This plan should help the student review and solidify what they learned from Saturday to Thursday.

Instructions for the revision plan:
1.  Create a section titled "### শুক্রবারের বিশেষ রিভিশন রুটিন" (Friday's Special Revision Routine).
2.  Generate a timetable for Friday using a Markdown table. The columns should be 'সময়' (Time) and 'করণীয়' (Task).
3.  The plan should focus ONLY on revising subjects, especially the ones listed as weaker subjects: **${formData.weakSubjects}**.
4.  Suggest specific revision activities. Instead of just listing the subject, suggest tasks like 'পদার্থবিজ্ঞান: গতির অধ্যায়ের নোট পুনরায় পড়ুন ও অনুশীলনীর সমস্যা সমাধান করুন' (Physics: Reread notes of the Motion chapter & solve exercise problems) or 'রসায়ন: পর্যায় সারণী না দেখে লেখার চেষ্টা করুন' (Chemistry: Try to write the periodic table without looking).
5.  Allocate time for a short weekly practice test ('সাপ্তাহিক মডেল টেস্ট') covering the topics studied during the week.
6.  Keep the total revision time reasonable, respecting the student's weekend. It should not exceed the daily study hours (${formData.studyHours} hours) and should include breaks.
7.  The output must be a single, well-formatted Markdown table in Bengali.
  `;
}


const callGeminiStream = async (
  prompt: string,
  onChunk: (chunk: string) => void
) => {
   try {
    const responseStream = await ai.models.generateContentStream({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    for await (const chunk of responseStream) {
      onChunk(chunk.text);
    }
  } catch (error) {
    console.error("Error generating content from Gemini API:", error);
    const errorMessage = parseGeminiError(error);
    throw new Error(errorMessage);
  }
}

export const generateStudyPlan = async (
  formData: FormData,
  onChunk: (chunk: string) => void
): Promise<void> => {
  const prompt = buildPrompt(formData);
  await callGeminiStream(prompt, onChunk);
};


export const generateRevisionPlan = async (
  formData: FormData,
  studyPlan: string,
  onChunk: (chunk: string) => void
): Promise<void> => {
  const prompt = buildRevisionPrompt(formData, studyPlan);
  await callGeminiStream(prompt, onChunk);
};