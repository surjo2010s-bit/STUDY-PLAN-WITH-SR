import React, { useState, useCallback } from 'react';
import type { FormData } from './types';
import { AcademicLevel } from './types';
import StudyPlannerForm from './components/StudyPlannerForm';
import StudyPlanDisplay from './components/StudyPlanDisplay';
import { generateStudyPlan, generateRevisionPlan } from './services/geminiService';
import { parseMarkdownTable } from './utils/markdownParser';
import { AppIcon } from './components/icons';
import type { TimetableData } from './types';

const App: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    level: AcademicLevel.SSC,
    subjects: 'Bangla 1st, English 1st, Math, Physics, Chemistry',
    chapters: '',
    examDate: new Date(new Date().setMonth(new Date().getMonth() + 3)).toISOString().split('T')[0],
    studyHours: '4',
    weakSubjects: 'Physics, Math',
    commitments: 'School from 8am to 1pm',
    includeWeakSubjectsDaily: true,
  });
  const [studyPlan, setStudyPlan] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const [revisionPlan, setRevisionPlan] = useState<string>('');
  const [isRevisionLoading, setIsRevisionLoading] = useState<boolean>(false);
  const [revisionError, setRevisionError] = useState<string>('');
  
  const [timetableData, setTimetableData] = useState<TimetableData | null>(null);


  const handleFormChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (e.target instanceof HTMLInputElement && type === 'checkbox') {
      setFormData(prev => ({ ...prev, [name]: e.target.checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  }, []);

  const handleSubmit = useCallback(async () => {
    setIsLoading(true);
    setError('');
    setStudyPlan('');
    setRevisionPlan('');
    setRevisionError('');
    setTimetableData(null);
    let fullPlan = '';
    try {
      await generateStudyPlan(formData, (chunk) => {
        fullPlan += chunk;
        setStudyPlan(prevPlan => prevPlan + chunk);
      });
      const parsedTable = parseMarkdownTable(fullPlan);
      if(parsedTable) {
        setTimetableData(parsedTable);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to generate study plan. Please check your connection and try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [formData]);
  
  const handleGenerateRevisionPlan = useCallback(async () => {
    if (!studyPlan) return;
    setIsRevisionLoading(true);
    setRevisionError('');
    setRevisionPlan('');
    try {
      await generateRevisionPlan(formData, studyPlan, (chunk) => {
        setRevisionPlan(prevPlan => prevPlan + chunk);
      });
    } catch (err: any) {
      setRevisionError(err.message || 'Failed to generate revision plan. Please try again.');
      console.error(err);
    } finally {
      setIsRevisionLoading(false);
    }
  }, [formData, studyPlan]);

  const handleTimetableDataChange = useCallback((newTimetableData: TimetableData) => {
    setTimetableData(newTimetableData);
  }, []);


  return (
    <div className="min-h-screen bg-planner-bg text-planner-text">
      <header className="bg-white/80 backdrop-blur-sm shadow-sm sticky top-0 z-10 border-b border-planner-pink-light">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-4">
          <AppIcon />
          <h1 className="text-2xl md:text-3xl font-bold font-handwriting tracking-wider text-planner-text">
            Surjo Roy
          </h1>
        </div>
      </header>
      
      <main className="container mx-auto p-4 sm:p-6 lg:p-8">
        <div className="flex flex-col gap-8 max-w-4xl mx-auto">
          <div>
            <StudyPlannerForm
              formData={formData}
              onFormChange={handleFormChange}
              onSubmit={handleSubmit}
              isLoading={isLoading}
            />
          </div>
          <div>
            <StudyPlanDisplay
              plan={studyPlan}
              isLoading={isLoading}
              error={error}
              revisionPlan={revisionPlan}
              isRevisionLoading={isRevisionLoading}
              revisionError={revisionError}
              onGenerateRevisionPlan={handleGenerateRevisionPlan}
              timetableData={timetableData}
              onTimetableUpdate={handleTimetableDataChange}
              weakSubjects={formData.weakSubjects}
            />
          </div>
        </div>
      </main>
      
      <footer className="text-center py-6 text-sm text-planner-text/70">
        <p>Powered by Gemini. Designed for Bangladeshi students.</p>
      </footer>
    </div>
  );
};

export default App;