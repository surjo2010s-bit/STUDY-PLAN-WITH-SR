import React, { useState } from 'react';
import Spinner from './Spinner';
import type { TimetableData } from '../types';
import DraggableTimetable from './DraggableTimetable';

declare global {
  interface Window {
    marked: {
      parse: (markdown: string) => string;
    };
    jspdf: any;
    html2canvas: any;
  }
}

interface StudyPlanDisplayProps {
  plan: string;
  isLoading: boolean;
  error: string;
  revisionPlan: string;
  isRevisionLoading: boolean;
  revisionError: string;
  onGenerateRevisionPlan: () => void;
  timetableData: TimetableData | null;
  onTimetableUpdate: (newTimetableData: TimetableData) => void;
  weakSubjects: string;
}

const StudyPlanDisplay: React.FC<StudyPlanDisplayProps> = ({ 
  plan, 
  isLoading, 
  error,
  revisionPlan,
  isRevisionLoading,
  revisionError,
  onGenerateRevisionPlan,
  timetableData,
  onTimetableUpdate,
  weakSubjects
}) => {
  const [isDownloading, setIsDownloading] = useState<boolean>(false);

  const handleDownloadPdf = async () => {
    if (!window.jspdf || !window.html2canvas) {
      console.error("PDF generation libraries not loaded.");
      alert("Could not download PDF. Please try again in a moment.");
      return;
    }

    const element = document.getElementById('timetable-to-download');
    if (!element) {
      console.error("Timetable element not found");
      return;
    }

    setIsDownloading(true);

    try {
      const { jsPDF } = window.jspdf;
      const canvas = await window.html2canvas(element, {
        scale: 2, 
        useCORS: true,
        backgroundColor: '#FFF9F9'
      });
      const imgData = canvas.toDataURL('image/png');

      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'px',
        format: 'a4'
      });

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();

      const imgProps = pdf.getImageProperties(imgData);
      const imgWidth = imgProps.width;
      const imgHeight = imgProps.height;

      const ratio = Math.min((pdfWidth - 20) / imgWidth, (pdfHeight - 20) / imgHeight);

      const imgX = (pdfWidth - imgWidth * ratio) / 2;
      const imgY = 10;

      pdf.addImage(imgData, 'PNG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);
      pdf.save('SurjoRoy_Study_Plan.pdf');
    } catch (e) {
      console.error("Error generating PDF:", e);
      alert("An error occurred while generating the PDF.");
    } finally {
      setIsDownloading(false);
    }
  };

  const renderRevisionSection = () => {
    if (isRevisionLoading) {
      return (
         <div className="flex flex-col items-center justify-center text-center mt-6">
          <Spinner />
          <p className="mt-4 text-md font-medium text-planner-text">
            আপনার রিভিশন প্ল্যান তৈরি করা হচ্ছে...
          </p>
        </div>
      );
    }
    
    if (revisionError) {
       return (
        <div className="mt-6 text-center text-red-600 bg-red-50 p-4 rounded-lg">
          <p className="font-semibold">একটি ত্রুটি ঘটেছে</p>
          <p className="text-sm">{revisionError}</p>
        </div>
      );
    }

    if (revisionPlan) {
      return (
         <div 
            className="timetable-output mt-6 pt-6 border-t border-planner-pink-dark/20"
            dangerouslySetInnerHTML={{ __html: window.marked.parse(revisionPlan) }}
          />
      );
    }

    return null;
  }

  const renderContent = () => {
    if (isLoading && !plan) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-center">
          <Spinner />
          <p className="mt-4 text-lg font-medium text-planner-text">
            আপনার জন্য ব্যক্তিগত স্টাডি প্ল্যান তৈরি করা হচ্ছে...
          </p>
          <p className="text-sm text-planner-text/70">এতে কিছুক্ষণ সময় লাগতে পারে।</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-center text-red-600 bg-red-50 p-6 rounded-lg">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <p className="mt-4 text-lg font-semibold">একটি ত্রুটি ঘটেছে</p>
          <p className="text-sm">{error}</p>
        </div>
      );
    }
    
    if (plan) {
       const tableRegex = /### সাপ্তাহিক আদর্শ রুটিন\s*\|.*\|[\s\S]*/;
       const tableMatch = plan.match(tableRegex);
       const contentBeforeTable = tableMatch ? plan.substring(0, tableMatch.index) : plan;
      return (
        <>
          <div className="flex justify-center gap-4 mb-4">
            <button
              onClick={handleDownloadPdf}
              disabled={isDownloading}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-planner-text hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-planner-pink-dark disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
            >
              {isDownloading ? 'ডাউনলোড হচ্ছে...' : 'পিডিএফ ডাউনলোড করুন'}
            </button>
            {!isLoading && !revisionPlan && (
               <button
                onClick={onGenerateRevisionPlan}
                disabled={isRevisionLoading}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-planner-text bg-white hover:bg-planner-pink-light focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-planner-pink-dark disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
              >
                {isRevisionLoading ? 'তৈরি হচ্ছে...' : 'সাপ্তাহিক রিভিশন প্ল্যান তৈরি করুন'}
              </button>
            )}
          </div>
           <div id="timetable-to-download">
             <div
                className="timetable-output"
                dangerouslySetInnerHTML={{ __html: window.marked.parse(contentBeforeTable) }}
              />

              {timetableData ? (
                <>
                  <div className="bg-planner-pink-light/50 border-l-4 border-planner-pink-dark text-planner-text p-4 my-4 rounded-r-lg">
                    <p className="font-bold font-handwriting">প্রো টিপস:</p>
                    <p className="text-sm">আপনার প্রয়োজন অনুযায়ী বিষয়গুলো এক ঘর থেকে অন্য ঘরে টেনে এনে রুটিনটি সাজিয়ে নিতে পারেন।</p>
                  </div>
                  <h3 className="font-kalam text-planner-text text-2xl font-bold text-center mb-4">সাপ্তাহিক আদর্শ রুটিন</h3>
                  <DraggableTimetable 
                    data={timetableData} 
                    onUpdate={onTimetableUpdate}
                    weakSubjects={weakSubjects} 
                  />
                </>
              ) : (
                // Fallback for when parsing fails or is in progress
                tableMatch && (
                  <div
                    className="timetable-output"
                    dangerouslySetInnerHTML={{ __html: window.marked.parse(tableMatch[0]) }}
                  />
                )
              )}
          </div>
          {renderRevisionSection()}
        </>
      );
    }

    return (
      <div className="flex flex-col items-center justify-center h-full text-center bg-white p-8 rounded-lg shadow-lg border border-planner-pink-light">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-planner-pink-dark" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
        </svg>
        <h3 className="mt-4 text-xl font-bold font-handwriting text-planner-text">সূর্য রায়-এ আপনাকে স্বাগতম</h3>
        <p className="mt-2 text-planner-text/80">
          আপনার অধ্যয়নের বিবরণ পূরণ করুন এবং একটি ব্যক্তিগত সাপ্তাহিক রুটিন পেতে "আমার স্টাডি প্ল্যান তৈরি করুন" বোতামে ক্লিক করুন।
        </p>
      </div>
    );
  };

  return (
    <div className="bg-planner-pink-light/30 p-4 sm:p-6 rounded-lg shadow-inner min-h-[600px] flex flex-col">
      {renderContent()}
    </div>
  );
};

export default StudyPlanDisplay;