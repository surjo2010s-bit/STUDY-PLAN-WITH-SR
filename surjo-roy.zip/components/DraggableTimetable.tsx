import React, { useState, useMemo } from 'react';
import type { TimetableData } from '../types';

interface DraggableTimetableProps {
  data: TimetableData;
  onUpdate: (newData: TimetableData) => void;
  weakSubjects: string;
}

const isDraggable = (content: string): boolean => {
  if (!content) return false;
  const lowerContent = content.toLowerCase();
  const nonDraggableKeywords = ['break', 'school', 'coaching', 'বিরতি', 'স্কুল', 'কোচিং', ''];
  return !nonDraggableKeywords.some(keyword => lowerContent.includes(keyword));
};

const DraggableTimetable: React.FC<DraggableTimetableProps> = ({ data, onUpdate, weakSubjects }) => {
  const [draggedItem, setDraggedItem] = useState<{ row: number; col: number } | null>(null);
  const [dragOverItem, setDragOverItem] = useState<{ row: number; col: number } | null>(null);

  // Memoize the list of weak subjects to avoid re-calculating on every render
  const weakSubjectList = useMemo(() => {
    return weakSubjects.split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
  }, [weakSubjects]);

  const isWeakSubject = (content: string): boolean => {
    if (!content || weakSubjectList.length === 0) return false;
    const lowerContent = content.toLowerCase();
    // Check if the cell content includes any of the user-defined weak subjects
    return weakSubjectList.some(weakSub => lowerContent.includes(weakSub));
  };

  const handleDragStart = (e: React.DragEvent<HTMLTableCellElement>, position: { row: number; col: number }) => {
    setDraggedItem(position);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', `${position.row},${position.col}`);
  };
  
  const handleDragOver = (e: React.DragEvent<HTMLTableCellElement>, position: { row: number; col: number }) => {
    e.preventDefault();
    if (position.col === 0) return; // Don't allow dropping on time column
    if (draggedItem?.row === position.row && draggedItem?.col === position.col) return;
    
    const targetContent = data.rows[position.row][position.col];
    if (isDraggable(targetContent) || targetContent.trim() === '') {
       setDragOverItem(position);
    }
  };

  const handleDragLeave = () => {
    setDragOverItem(null);
  }

  const handleDrop = (e: React.DragEvent<HTMLTableCellElement>, targetPosition: { row: number; col: number }) => {
    e.preventDefault();
    setDragOverItem(null);

    if (!draggedItem) return;
    if (targetPosition.col === 0) return; // Can't drop on time column

    const sourcePosition = draggedItem;
    
    // Prevent dropping a non-draggable item, just in case
    const sourceContent = data.rows[sourcePosition.row][sourcePosition.col];
    if (!isDraggable(sourceContent)) {
        setDraggedItem(null);
        return;
    }

    const targetContent = data.rows[targetPosition.row][targetPosition.col];
    // Allow dropping on another draggable item or an empty cell
    if (isDraggable(targetContent) || targetContent.trim() === '') {
        const newRows = [...data.rows.map(row => [...row])]; // Deep copy
        
        // Swap
        [newRows[sourcePosition.row][sourcePosition.col], newRows[targetPosition.row][targetPosition.col]] =
        [newRows[targetPosition.row][targetPosition.col], newRows[sourcePosition.row][sourcePosition.col]];
        
        onUpdate({ ...data, rows: newRows });
    }
    
    setDraggedItem(null);
  };

  const handleDragEnd = () => {
    setDraggedItem(null);
    setDragOverItem(null);
  };


  return (
    <div className="timetable-output">
      <table>
        <thead>
          <tr>
            {data.headers.map((header, index) => (
              <th key={index}>{header}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.rows.map((row, rowIndex) => (
            <tr key={rowIndex}>
              {row.map((cell, colIndex) => {
                const draggable = isDraggable(cell);
                const isWeak = isWeakSubject(cell);
                const isBeingDragged = draggedItem?.row === rowIndex && draggedItem?.col === colIndex;
                const isDragOver = dragOverItem?.row === rowIndex && dragOverItem?.col === colIndex;

                let cellClass = '';
                 // Apply a special background for weak subjects to highlight them
                if (isWeak) {
                  cellClass += ' bg-amber-100/60';
                }
                if (draggable) {
                    cellClass += ' cursor-move';
                }
                if (isBeingDragged) {
                    cellClass += ' opacity-50 bg-planner-pink-dark/20';
                }
                if(isDragOver) {
                    cellClass += ' outline-dashed outline-2 outline-planner-text';
                }

                return (
                  <td
                    key={colIndex}
                    draggable={draggable}
                    onDragStart={(e) => handleDragStart(e, { row: rowIndex, col: colIndex })}
                    onDragOver={(e) => handleDragOver(e, { row: rowIndex, col: colIndex })}
                    onDrop={(e) => handleDrop(e, { row: rowIndex, col: colIndex })}
                    onDragEnd={handleDragEnd}
                    onDragLeave={handleDragLeave}
                    className={cellClass}
                  >
                    {cell}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DraggableTimetable;