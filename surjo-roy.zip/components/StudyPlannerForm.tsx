import React from 'react';
import type { FormData } from '../types';
import { AcademicLevel } from '../types';

interface StudyPlannerFormProps {
  formData: FormData;
  onFormChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onSubmit: () => void;
  isLoading: boolean;
}

const InputField: React.FC<{ label: string; name: string; value: string; onChange: any; placeholder?: string; type?: string; required?: boolean }> = ({ label, name, value, onChange, placeholder, type = 'text', required = true }) => (
  <div>
    <label htmlFor={name} className="block text-sm font-medium text-planner-text/90 mb-1">
      {label}
    </label>
    <input
      type={type}
      id={name}
      name={name}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      required={required}
      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-planner-pink-dark focus:border-planner-pink-dark sm:text-sm transition duration-150 ease-in-out"
    />
  </div>
);

const TextAreaField: React.FC<{ label: string; name: string; value: string; onChange: any; placeholder?: string; rows?: number }> = ({ label, name, value, onChange, placeholder, rows = 3 }) => (
  <div>
    <label htmlFor={name} className="block text-sm font-medium text-planner-text/90 mb-1">
      {label}
    </label>
    <textarea
      id={name}
      name={name}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      rows={rows}
      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-planner-pink-dark focus:border-planner-pink-dark sm:text-sm transition duration-150 ease-in-out"
    />
  </div>
);

const StudyPlannerForm: React.FC<StudyPlannerFormProps> = ({ formData, onFormChange, onSubmit, isLoading }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg space-y-6 border border-planner-pink-light">
      <h2 className="text-xl font-bold font-handwriting text-planner-text">আপনার অধ্যয়নের বিবরণ</h2>
      
      <div>
        <label className="block text-sm font-medium text-planner-text/90 mb-1">
          শিক্ষাগত স্তর
        </label>
        <div className="flex gap-4">
          {Object.values(AcademicLevel).map(level => (
            <label key={level} className="flex items-center space-x-2 cursor-pointer">
              <input
                type="radio"
                name="level"
                value={level}
                checked={formData.level === level}
                onChange={onFormChange}
                className="h-4 w-4 text-planner-text border-slate-300 focus:ring-planner-text"
              />
              <span className="text-sm font-medium text-planner-text">{level}</span>
            </label>
          ))}
        </div>
      </div>

      <InputField
        label="বিষয়সমূহ (কমা দিয়ে আলাদা করুন)"
        name="subjects"
        value={formData.subjects}
        onChange={onFormChange}
        placeholder="যেমন: পদার্থবিজ্ঞান, রসায়ন, গণিত"
      />
      
      <TextAreaField
        label="বিষয় ও অধ্যায় (ঐচ্ছিক)"
        name="chapters"
        value={formData.chapters}
        onChange={onFormChange}
        placeholder={"যদি নির্দিষ্ট অধ্যায় উল্লেখ করতে চান। যেমন:\nপদার্থবিজ্ঞান: ভৌত রাশি, গতি\nরসায়ন: পদার্থের অবস্থা, পর্যায় সারণী"}
        rows={4}
      />

      <InputField
        label="পরীক্ষার তারিখ"
        name="examDate"
        value={formData.examDate}
        onChange={onFormChange}
        type="date"
      />
      
      <InputField
        label="দৈনিক পড়ার সময় (ঘণ্টা)"
        name="studyHours"
        value={formData.studyHours}
        onChange={onFormChange}
        type="number"
        placeholder="যেমন: ৫"
      />

      <TextAreaField
        label="দুর্বল বিষয় / অগ্রাধিকারের টপিক"
        name="weakSubjects"
        value={formData.weakSubjects}
        onChange={onFormChange}
        placeholder="যেমন: জৈব রসায়ন, ভেক্টর গণিত"
      />

      <div className="flex items-center">
        <input
          id="includeWeakSubjectsDaily"
          name="includeWeakSubjectsDaily"
          type="checkbox"
          checked={formData.includeWeakSubjectsDaily}
          onChange={onFormChange}
          className="h-4 w-4 rounded border-slate-300 text-planner-text focus:ring-planner-text"
        />
        <label htmlFor="includeWeakSubjectsDaily" className="ml-3 block text-sm font-medium text-planner-text/90">
          দুর্বল বিষয়গুলো প্রতিদিনের রুটিনে রাখুন
        </label>
      </div>
      
      <TextAreaField
        label="ক্লাস বা কোচিংয়ের সময়"
        name="commitments"
        value={formData.commitments}
        onChange={onFormChange}
        placeholder="যেমন: কোচিং বিকাল ৪টা থেকে ৬টা"
        rows={2}
      />

      <button
        onClick={onSubmit}
        disabled={isLoading}
        className="w-full flex justify-center items-center px-4 py-3 border border-transparent text-base font-semibold rounded-md shadow-sm text-white bg-planner-text hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-planner-pink-dark disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 ease-in-out"
      >
        {isLoading ? (
          <>
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            তৈরি হচ্ছে...
          </>
        ) : (
          'আমার স্টাডি প্ল্যান তৈরি করুন'
        )}
      </button>
    </div>
  );
};

export default StudyPlannerForm;