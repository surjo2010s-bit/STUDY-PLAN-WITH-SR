
import React from 'react';

export const AppIcon: React.FC = () => (
  <div className="p-2 bg-planner-text rounded-lg shadow-md">
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      className="h-6 w-6 text-white" 
      fill="none" 
      viewBox="0 0 24 24" 
      stroke="currentColor" 
      strokeWidth={2}>
        <path 
          strokeLinecap="round" 
          strokeLinejoin="round" 
          d="M12 6.253v11.494m-9-5.747h18M5.45 5.11l13.097 13.097M5.45 18.207L18.547 5.11" 
        />
    </svg>
  </div>
);