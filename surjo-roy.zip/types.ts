export enum AcademicLevel {
  SSC = 'SSC',
  HSC = 'HSC',
}

export interface FormData {
  level: AcademicLevel;
  subjects: string;
  chapters: string;
  examDate: string;
  studyHours: string;
  weakSubjects: string;
  commitments: string;
  includeWeakSubjectsDaily: boolean;
}

export interface TimetableData {
  headers: string[];
  rows: string[][];
}
